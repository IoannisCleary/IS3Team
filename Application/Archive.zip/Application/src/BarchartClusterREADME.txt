================
BARCHART CLUSTER
================

1) Instantiate as you would a JPanel (it extends JPanel so anything else you wanna do is available)
2) If you want to test that it's working as it should, I've written a test() method that will produce 4 bargraphs

BarchartCluster cluster = new BarchartCluster();
cluster.test();

THANKS!